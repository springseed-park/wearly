// OpenWeatherMap API 키
const API_KEY = '7efbae72b31b034262cddb36a41913dd';
const API_URL = 'https://api.openweathermap.org/data/2.5/weather';

// API 호출을 위해 한글 지역명을 영문 도시명으로 매핑합니다.
const regionMap: { [key: string]: string } = {
  '서울': 'Seoul',
  '부산': 'Busan',
  '대구': 'Daegu',
  '인천': 'Incheon',
  '광주': 'Gwangju',
  '대전': 'Daejeon',
  '울산': 'Ulsan',
  '세종': 'Sejong',
  '경기': 'Suwon',
  '강원': 'Chuncheon',
  '충북': 'Cheongju',
  '충남': 'Hongseong',
  '전북': 'Jeonju',
  '전남': 'Mokpo',
  '경북': 'Andong',
  '경남': 'Changwon',
  '제주': 'Jeju',
};

export interface WeatherData {
    summary: string;
    temp: number;
    minTemp: number;
    maxTemp: number;
}

/**
 * OpenWeatherMap API를 사용하여 특정 지역의 날씨 정보를 가져옵니다.
 * @param region 날씨를 조회할 한글 지역명
 * @returns 포맷팅된 날씨 데이터
 */
export async function getWeatherByRegion(region: string): Promise<WeatherData> {
    const cityName = regionMap[region];
    if (!cityName) {
        throw new Error(`'${region}' 지역에 대한 영문 도시명을 찾을 수 없습니다.`);
    }

    const url = `${API_URL}?q=${cityName},kr&appid=${API_KEY}&units=metric&lang=kr`;

    try {
        const response = await fetch(url);
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(`날씨 API 오류: ${errorData.message || response.statusText}`);
        }
        const data = await response.json();

        // API 응답에서 필요한 데이터를 추출하고 가공합니다.
        const weatherData: WeatherData = {
            summary: data.weather[0]?.description || '알 수 없음',
            temp: Math.round(data.main.temp),
            minTemp: Math.round(data.main.temp_min),
            maxTemp: Math.round(data.main.temp_max),
        };

        return weatherData;
    } catch (error) {
        console.error("Error fetching weather from OpenWeatherMap:", error);
        throw new Error("실시간 날씨 정보를 가져오는 데 실패했습니다. API 키나 지역명을 확인해주세요.");
    }
}
