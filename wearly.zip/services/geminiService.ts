import { GoogleGenAI, Type, Modality } from "@google/genai";
import type { Gender, Tone } from '../types';
import { REGIONS } from '../constants';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const fileToBase64 = (file: File): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve((reader.result as string).split(',')[1]);
    reader.onerror = (error) => reject(error);
  });

const getCurrentDateText = (): string => {
  const today = new Date();
  const year = today.getFullYear();
  const month = today.getMonth() + 1;
  const day = today.getDate();
  return `오늘 날짜는 ${year}년 ${month}월 ${day}일이야.`;
};

const getGenderPromptText = (gender: Gender): string => {
  if (gender === 'male') return '남성';
  if (gender === 'female') return '여성';
  return '';
};

// User-suggested regional style context
const regionalStyleContext = `
  <지역별 패션 스타일 가이드>
  - 서울: 트렌디하고 미니멀한 스타일. 시크한 도시 감성.
  - 부산: 자유분방하고 캐주얼한 스타일. 해변과 어울리는 편안함.
  - 대구: 과감하고 패셔너블함. 더운 날씨 영향으로 시원하고 개성 있는 옷차림.
  - 광주: 예술적이고 독창적인 스타일.
  - 제주: 자연 친화적이고 실용적인 리조트 룩.
  - 인천: 국제공항과 항구도시 특성상 실용적이면서도 국제적인 감각이 섞인 스타일.
  - 대전: 교통의 중심지이자 연구 도시로, 단정하고 지적인 캐주얼 스타일.
  - 울산: 산업 도시 특성상 활동적이고 실용적인 워크웨어 스타일.
  - 세종: 행정 중심 신도시로, 깔끔하고 현대적인 비즈니스 캐주얼.
  - 경기: 서울 근교의 특성을 반영해, 트렌디하면서도 편안한 '꾸안꾸' 스타일.
  - 강원: 산과 자연의 영향으로 기능성과 스타일을 겸비한 고프코어 및 아웃도어 룩.
  - 충청(충북/충남): 온화하고 무난한 지역 특성을 반영한 편안하고 실용적인 스타일.
  - 전라(전북/전남): 예향의 도시답게, 여유롭고 멋스러운 스타일.
  - 경상(경북/경남): 지역적 특색이 강하며, 활동적이면서도 보수적인 면이 공존하는 스타일.
  이 가이드를 바탕으로 지역에 맞는 미묘한 스타일 차이를 조언에 녹여줘.
`;

const getPersonaPrompt = (tone: Tone): string => {
  const basePersona = "너는 '웨어리', 사용자의 친한 패션 고수 친구이자 AI 코디네이터야.";
  switch (tone) {
    case 'witty':
      return `${basePersona} 웃긴 드립 잘 치는 유쾌한 성격이야. 반말로 짧고 재밌게 대화해. 엉뚱한 농담으로 팩폭하는 거 완전 환영. ㅋㅋ (예: '그 옷 입고 북극곰이랑 친구 먹으러 가냐? 🤣')`;
    case 'critical':
      return `${basePersona} 패션에 대해선 까칠하고 직설적인 팩폭러야. 반말로 핵심만 짧게 찔러줘. 잘못된 옷차림은 절대 용납 못함. (예: '10도에 나시? 얼죽아 패션임? 당장 코트 걸쳐!')`;
    case 'friendly':
    default:
      return `${basePersona} 다정하고 친절해. 젊은 사람들이 카톡하듯, 짧고 친근하게 존댓말로 말해줘. 이모티콘도 적절히 사용해봐. 😉`;
  }
};

export async function getRegionFromCoords(lat: number, lon: number): Promise<string | null> {
  const prompt = `
    대한민국 위도 ${lat}, 경도 ${lon}에 해당하는 지역명을 다음 리스트에서 하나만 골라줘.
    [${REGIONS.join(', ')}]
    다른 말은 절대 하지 말고, 리스트에 있는 지역명 하나만 정확히 말해줘.
    예시: 서울
  `;
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    const region = response.text.trim();
    if (REGIONS.includes(region)) {
      return region;
    }
    return null;
  } catch (error) {
    console.error("Error getting region from coordinates:", error);
    return null;
  }
}

export async function generateOutfitImage(description: string, gender: Gender): Promise<string | null> {
  try {
    const genderPromptText = gender === 'male' ? 'a man' : gender === 'female' ? 'a woman' : 'a person';
    const prompt = `A realistic, full-body fashion photo of ${genderPromptText} wearing ${description}. Clean, minimalist studio background. Centered, photorealistic, no text or logos.`;
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [{ text: prompt }],
      },
      config: {
        responseModalities: [Modality.IMAGE],
      },
    });

    const part = response.candidates?.[0]?.content?.parts?.[0];
    if (part?.inlineData) {
      const { data, mimeType } = part.inlineData;
      return `data:${mimeType};base64,${data}`;
    }
    return null;
  } catch (error) {
    console.error("Error generating outfit image:", error);
    return null;
  }
}

export async function getWeatherAndRecommendation(region: string, gender: Gender, tone: Tone) {
  try {
    const genderText = getGenderPromptText(gender);
    const todayDateText = getCurrentDateText();

    const personaInstruction = {
      friendly: "이 날씨에 어울리는 옷차림을 친한 친구처럼 짧고 친근하게 존댓말로 추천해줘. 이모티콘도 좋아! 😉",
      witty: "이 날씨에 맞춰 옷 어떻게 입을지 반말로 짧고 위트있게 알려줘. 드립 환영 ㅋㅋ",
      critical: "이 날씨에 맞는 옷차림을 반말로 짧고 직설적으로 알려줘. 잘못 입으면 팩폭ㄱㄱ"
    }[tone] || "오늘 날씨에 어울리는 옷차림을 친한 친구처럼 짧고 친근하게 존댓말로 추천해줘. 이모티콘도 좋아! 😉";

    const prompt = `
      너는 대한민국 날씨 전문가이자 패션 AI '웨어리'야.
      ${todayDateText} 이건 한국 시간 기준이야.
      
      <미션>
      1. **날씨 검색:** '${region}'의 '오늘' 날씨 정보를 검색해.
         - **필수 검색 소스:** 대한민국 기상청, weatheri.co.kr. 이 두 곳을 최우선으로 사용해줘.
         - **필수 정보:** 오늘 최저 기온, 오늘 최고 기온, 날씨 요약(예: 맑음, 흐림). '현재 기온'은 필요 없어.
         - **중요:** 검색 결과가 없거나 부정확하면 다른 신뢰할 수 있는 한국 날씨 사이트를 참고해서라도 반드시 정확한 정보를 찾아내야 해.
      
      2. **옷차림 추천:** 검색한 날씨 정보를 바탕으로 ${genderText ? `${genderText}을 위한` : ''} 옷차림 추천을 생성해줘.
      
      <말투 및 형식>
      - **말투:** '${personaInstruction}' 이걸 꼭 지켜줘.
      - **출력 형식:** 다른 말은 절대 하지 말고, 반드시 아래 JSON 형식으로만 답변해. 온도 데이터는 반드시 숫자 타입이어야 해.

      {
        "summary": "오늘의 날씨 요약 (예: '맑음', '구름 많음')",
        "minTemp": 10,
        "maxTemp": 20,
        "suggestion": "오늘 날씨에 딱 맞는 옷차림 추천 문구."
      }
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        tools: [{googleSearch: {}}],
      },
    });
    
    let jsonString = response.text.trim();
    const jsonMatch = jsonString.match(/```(json\s*)?([\s\S]*?)```/);
    if (jsonMatch && jsonMatch[2]) {
      jsonString = jsonMatch[2];
    }
    
    const parsed = JSON.parse(jsonString);
    return parsed;

  } catch (error) {
    console.error("Error getting weather and recommendation via search:", error);
    throw new Error("날씨 기반 추천을 생성하는 데 실패했습니다. 잠시 후 다시 시도해주세요.");
  }
}

export async function getTextRecommendation(text: string, region: string | null, gender: Gender, tone: Tone) {
  const prompt = `
    ${getPersonaPrompt(tone)}
    ${getCurrentDateText()}
    사용자 요청: "${text}".
    ${region ? `여기는 ${region}이고,` : ''} 현재 날짜, 계절과 온도를 반드시 고려해서 답변해.
    ${regionalStyleContext}
    
    응답은 반드시 다음 JSON 형식으로! 답변은 짧고 간결하게!
    {
      "advice": "패션 조언. 아주 짧고, 강렬하고, 재밌게.",
      "quickReplies": [ "이 코디 이미지로 보여줘", "다른 스타일 추천해줘", "신발은 뭐 신지?" ]
    }
  `;
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            advice: { type: Type.STRING, description: '사용자 요청에 기반한 짧고 간결한 옷차림 추천' },
            quickReplies: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: '추천 후속 질문 3가지. 첫번째는 항상 "이 코디 이미지로 보여줘"여야 합니다.',
            },
          },
          required: ["advice", "quickReplies"],
        },
      },
    });

    const parsed = JSON.parse(response.text);
    return parsed;
  } catch (error) {
    console.error("Error getting text recommendation:", error);
    throw new Error("텍스트 기반 추천을 생성하는 데 실패했습니다.");
  }
}

export async function getImageRecommendation(imageFile: File, text: string, region: string | null, gender: Gender, tone: Tone) {
  const base64Image = await fileToBase64(imageFile);

  const imagePart = {
    inlineData: {
      mimeType: imageFile.type,
      data: base64Image,
    },
  };
  
  const genderText = getGenderPromptText(gender);
  const textPart = {
      text: `
        ${getPersonaPrompt(tone)}
        ${getCurrentDateText()}
        
        <역할>
        너는 사용자가 올린 사진 속 옷차림을 보고, 2단계에 걸쳐 답변해야 해.
        
        <1단계: 분석>
        - 사진 속 옷차림 어떤지 현재 날씨(${region ? ` ${region} 참고` : ''})에 맞춰서, ${tone} 말투로 짧게 팩폭해줘. 'analysis' 필드에 담아줘.
        
        <2단계: 제안>
        - 더 나은 코디를 'suggestion' 필드에 짧고 간결하게 제안해줘. 이 텍스트는 이미지 생성에 쓰일 거니까 스타일 묘사는 명확하게! (예: '화이트 크롭탑, 연청 와이드 데님, 베이지 블레이저로 시크하게')
        
        <사용자 추가 정보>
        - 사용자 메시지: "${text || '없음'}"
        ${genderText ? `- 성별: ${genderText}` : ''}
        ${regionalStyleContext}
        
        <출력 형식>
        - 분석, 제안, 그리고 2개의 후속 질문을 포함한 JSON 형식으로만 응답해줘. 답변은 무조건 짧고 간결하게!
        - 후속 질문(quickReplies)의 첫번째는 항상 "제안된 코디 이미지로 보여줘" 여야 해.
      `
  };
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: { parts: [imagePart, textPart] },
       config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            analysis: { type: Type.STRING, description: '사진 속 옷차림에 대한 짧고 간결한 분석 및 평가' },
            suggestion: { type: Type.STRING, description: '분석을 기반으로 한 새로운 옷차림 제안 (이미지 생성용)' },
            quickReplies: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: '추천 후속 질문 2가지. 첫번째는 항상 "제안된 코디 이미지로 보여줘"여야 합니다.',
            },
          },
          required: ["analysis", "suggestion", "quickReplies"],
        },
      },
    });
    const parsed = JSON.parse(response.text);
    return parsed;
  } catch (error) {
    console.error("Error getting image recommendation:", error);
    throw new Error("이미지 기반 추천을 생성하는 데 실패했습니다.");
  }
}